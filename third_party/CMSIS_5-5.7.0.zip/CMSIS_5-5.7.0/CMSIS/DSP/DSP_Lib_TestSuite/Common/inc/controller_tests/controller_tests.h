#ifndef _CONTROLLER_TESTS_H_
#define _CONTROLLER_TESTS_H_

/*--------------------------------------------------------------------------------*/
/* Test/Group Declarations */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(pid_reset_tests);
JTEST_DECLARE_GROUP(sin_cos_tests);
JTEST_DECLARE_GROUP(pid_tests);

#endif /* _CONTROLLER_TESTS_H_ */
